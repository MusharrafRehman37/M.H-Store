const mongoose = require("mongoose");
const cartItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  name: { type: String, required: true }, price: { type: Number, required: true, min: 0 },
  image: { type: String, required: true }, category: { type: String, default: "" },
  quantity: { type: Number, default: 1, min: 1 },
}, { _id: false });
const cartSchema = new mongoose.Schema({ userId: { type: String, required: true, unique: true }, items: { type: [cartItemSchema], default: [] } }, { timestamps: true });
module.exports = mongoose.model("Cart", cartSchema);
